﻿# SE_starter_code
This project is a simple project for metro station with a greate algrothim ,it is a uni project 
